package com.example.myapplication;

public interface TrainConfiguration {
    String getConfiguration();
}
